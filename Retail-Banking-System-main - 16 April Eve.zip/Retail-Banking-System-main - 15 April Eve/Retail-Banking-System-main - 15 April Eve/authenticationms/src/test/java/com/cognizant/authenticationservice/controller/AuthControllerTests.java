package com.cognizant.authenticationservice.controller;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;


import org.springframework.http.MediaType;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.mockito.BDDMockito.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cognizant.authenticationservice.model.AuthenticationResponse;

import java.util.Date;


@RunWith(SpringRunner.class)
@AutoConfigureMockMvc
@SpringBootTest(value = { "eureka.client.enabled:false", "server.port:0" })
public class AuthControllerTests {
	
	@Autowired
	MockMvc mockMvc;
	
	private static String VALID_AUTH_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJhZG1pbiIsImV4cCI6MTYxODU1MzUwMSwiaWF0IjoxNjE4NTUxNzAxfQ.0xvMlWG6IJP1p4O9tYTiGrWftH11Pm58v1Y-L7rdZ-E";

	
	
	@Test
	public void loginCustomerTest() throws Exception {
		
		String content = "{\"userid\":1, \"username\":\"vijay\", \"password\":\"vijay\",\"authToken\":null,\"role\":\"CUSTOMER\"}";
		
		ResultActions  actions = mockMvc.perform(post("/login").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","")).andExpect(status().isAccepted());
		
		actions.andExpect(jsonPath("userid").value("1"));
		
		actions.andReturn();
	}
	

	@Test
	public void validateTokenTest() throws Exception{
		String content = "{}";
		ResultActions  actions = mockMvc.perform(get("/validateToken").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","Bearer " + VALID_AUTH_TOKEN)).andExpect(status().isOk());
		actions.andExpect(jsonPath("valid").value("true"));actions.andReturn();
	}
	
	@Test
	public void createUserTest() throws Exception{
		String content = "{\"userid\":18, \"username\":\"prasad\", \"password\":\"prasad\",\"authToken\":null,\"role\":\"CUSTOMER\"}";
		ResultActions  actions = mockMvc.perform(post("/createUser").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","")).andExpect(status().isCreated());
		actions.andExpect(jsonPath("userid").value("18"));
		actions.andExpect(jsonPath("username").value("prasad"));
		actions.andExpect(jsonPath("password").value("prasad"));
		actions.andExpect(jsonPath("role").value("CUSTOMER"));
		actions.andReturn();
	}
	
	@Test
	public void findUsers() throws Exception{
		String content = "{}";
		ResultActions  actions = mockMvc.perform(get("/find").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","Bearer " + VALID_AUTH_TOKEN)).andExpect(status().isCreated());
		actions.andReturn();
	}
	
	
	@Test
	public void getEmployeeRoleTest() throws Exception{
		String content = "{}";
		ResultActions  actions = mockMvc.perform(get("/role/admin").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","")).andExpect(status().isOk());
		actions.andExpect(MockMvcResultMatchers.content().string("EMPLOYEE"));
		
		actions.andReturn();
		
	}
	
	@Test
	public void getCustomerRoleTest() throws Exception{
		String content = "{}";
		ResultActions  actions = mockMvc.perform(get("/role/1").contentType(MediaType.APPLICATION_JSON).content(content)
				.header("Authorization","")).andExpect(status().isOk());
		actions.andExpect(MockMvcResultMatchers.content().string("CUSTOMER"));
		actions.andReturn();	
	}
	
	
}
