package com.cognizant.authenticationservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthenticationMsApplicationTests {

	@Test
	void contextLoads() {
	}

}
