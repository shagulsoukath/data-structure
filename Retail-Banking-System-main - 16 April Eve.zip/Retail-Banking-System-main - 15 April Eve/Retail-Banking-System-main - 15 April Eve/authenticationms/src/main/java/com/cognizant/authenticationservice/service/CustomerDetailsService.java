package com.cognizant.authenticationservice.service;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cognizant.authenticationservice.model.AdminUser;
import com.cognizant.authenticationservice.model.AppUser;
import com.cognizant.authenticationservice.repository.AdminRepository;
import com.cognizant.authenticationservice.repository.UserRepository;
@Service
public class CustomerDetailsService implements UserDetailsService {

	// Class to Implement UserDetailsService in Spring security

	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private AdminRepository adminRepo;

	@Override
	public UserDetails loadUserByUsername(String userid) throws UsernameNotFoundException {

		AppUser user = userRepo.findByUserid(userid);
		AdminUser admin = adminRepo.findByUserid(userid);

		if (user != null) {
			List<GrantedAuthority> grantedAuthorities = AuthorityUtils
					.commaSeparatedStringToAuthorityList("ROLE_" + user.getRole());
			return new User(user.getUserid(), user.getPassword(), grantedAuthorities);
		} else if(admin != null){
			List<GrantedAuthority> grantedAuthorities = AuthorityUtils
					.commaSeparatedStringToAuthorityList("ROLE_" + admin.getRole());
			return new User(admin.getUserid(), admin.getPassword(), grantedAuthorities);
		}
		else {
			throw new UsernameNotFoundException("Username/Password is Invalid...Please Check");
		}
	}
//	
//	public UserDetails loadUserByUsername(String userid) throws UsernameNotFoundException {
//		List<SimpleGrantedAuthority> roles = null;
//		
//			
//		AppUser user = userRepo.findById(userid).get();
//		if (user != null) {
//			System.out.println("Inside User");
//			roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_"+user.getRole()));
//			System.out.println(roles);
//			return new User(user.getUsername(), user.getPassword(), roles);
//		}
//		
//		AdminUser admin = adminRepo.findById(userid).get();
//		if(admin!=null) {
//			System.out.println("Inside Admin");
//			roles = Arrays.asList(new SimpleGrantedAuthority("ROLE_"+admin.getRole()));
//			System.out.println(roles);
//			return new User(admin.getUsername(), admin.getPassword(), roles);
//		}
//		
//		throw new UsernameNotFoundException("User not found with the name " + userid);	}

}
