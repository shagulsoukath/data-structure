package com.cognizant.authenticationservice.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.authenticationservice.exceptionhandling.AppUserNotFoundException;
import com.cognizant.authenticationservice.model.AdminUser;
import com.cognizant.authenticationservice.model.AppUser;
import com.cognizant.authenticationservice.model.AuthenticationResponse;
import com.cognizant.authenticationservice.repository.AdminRepository;
import com.cognizant.authenticationservice.repository.UserRepository;
import com.cognizant.authenticationservice.service.CustomerDetailsService;
import com.cognizant.authenticationservice.service.JwtUtil;
import com.cognizant.authenticationservice.service.LoginService;
import com.cognizant.authenticationservice.service.Validationservice;

import lombok.extern.slf4j.Slf4j;


/**
 * The AuthController class for request controller
 *
 */
@Slf4j
@RestController
public class AuthController {

	// Users Repository
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private AdminRepository adminRepository;
	
	//Service class login
	@Autowired
	private LoginService loginService;
	
	//Service class for login
	@Autowired
	private Validationservice validationService;
	
	@Autowired
	private AuthenticationManager authenticationManager;
	

	@Autowired
	private JwtUtil jwtUtil;

	@Autowired
	private CustomerDetailsService userDetailsService;
	
	@Autowired
	private PasswordEncoder bcryptEncoder;
	
	@PostMapping("/login")
	public ResponseEntity<?> login(@RequestBody AppUser appUserloginCredentials) throws Exception {
		if(appUserloginCredentials.getRole().equals("CUSTOMER")) {
			AppUser user = loginService.userLogin(appUserloginCredentials);
			log.info("Credentials ----->{}",user);
			return new ResponseEntity<>(user , HttpStatus.ACCEPTED);
		}else {
			AdminUser user = loginService.adminLogin(new AdminUser(appUserloginCredentials.getUserid(), appUserloginCredentials.getUsername(), appUserloginCredentials.getPassword(), null, appUserloginCredentials.getRole()));
			log.info("Credentials ----->{}",user);
			return new ResponseEntity<>(user , HttpStatus.ACCEPTED);
		}
	}
	
	@GetMapping("/validateToken")
	public AuthenticationResponse getValidity(@RequestHeader("Authorization") final String token) {
		log.info("Token Validation ----->{}",token);
		return validationService.validate(token);
	}
	

	@PostMapping("/createUser")
	public ResponseEntity<?> createUser(@RequestBody AppUser appUserCredentials)
	{
		AppUser createduser = null;
		try {
			appUserCredentials.setPassword(appUserCredentials.getPassword());
			createduser = userRepository.save(appUserCredentials);
		}
		catch(Exception e)
		{
			return new ResponseEntity<String>("Not created" , HttpStatus.NOT_ACCEPTABLE);
		}
		log.info("user creation---->{}",createduser);
		return new ResponseEntity<>(createduser,HttpStatus.CREATED);
		
	}
	

	@PreAuthorize("hasRole('ROLE_EMPLOYEE')")
	@GetMapping("/find")
	public ResponseEntity<List<AppUser>> findUsers(@RequestHeader("Authorization") final String token)
	{
		List<AppUser> createduser =new ArrayList<>() ;
		List<AppUser> findAll = userRepository.findAll();
		findAll.forEach(emp->createduser.add(emp));
		log.info("All Users  ----->{}",findAll);
		return new ResponseEntity<>(createduser,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/role/{id}")
	public String getRole(@PathVariable String id) {
		try {
			return userRepository.findById(id).get().getRole();
		}catch(Exception ex) {
			return adminRepository.findById(id).get().getRole();
		}
	}
	
}