insert into rules values('minimumBalanceDeduction','Minimum Balance Deduction Amount',50);
insert into rules values('minimumBalanceForTransaction','must maintain 1000',1000);
insert into rules values('minimumBalanceServiceCharge','MinimumBalanceForServiceCharge',2000);