package com.rulesservice.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rulesservice.feign.AccountFeign;
import com.rulesservice.feign.AuthorizationFeign;
import com.rulesservice.exception.AccessDeniedException;
import com.rulesservice.model.AccountInput;
import com.rulesservice.model.AuthenticationResponse;
import com.rulesservice.model.RuleStatus;
import com.rulesservice.model.RulesInput;
import com.rulesservice.model.ServiceResponse;
import com.rulesservice.repository.RulesRepository;

@Service
public class RulesServiceImpl implements RulesService {
	
	@Autowired
	AuthorizationFeign authorizationFeign;
	
	@Autowired
	RulesRepository rulesRepository;
	
	public RuleStatus ruleStatus;
	 
 
	public RuleStatus evaluate(RulesInput account) {
		System.out.println("---------------------Inside Evaluate----------------------");
		double min=rulesRepository.findById("minimumBalanceForTransaction").get().getRulededuction();
		System.out.println(rulesRepository.findById("minimumBalanceForTransaction"));
		double check = account.getCurrentBalance() - account.getAmount();
		ruleStatus = new RuleStatus();
	    	if(check >= min) {
	    		ruleStatus.setStatus("allowed");
	    		return ruleStatus;
	    	}
	    	else {
	    		ruleStatus.setStatus("denied");
	    		return ruleStatus;
	    	}
	}
	
	public AuthenticationResponse hasPermission(String token) {
		AuthenticationResponse validity = authorizationFeign.getValidity(token);
		if (!authorizationFeign.getRole(validity.getUserid()).equals("EMPLOYEE"))
			throw new AccessDeniedException("NOT ALLOWED");
		else
			return validity;
	}

	public ServiceResponse serviceCharges(RulesInput account) {
		ServiceResponse response=new ServiceResponse();
		response.setAccountId(account.getAccountId());
		if(account.getCurrentBalance()<1000)
		{
			double detected=account.getCurrentBalance()/10;
			response.setMessage("Your Balance is lesser than the minimum balance so "+detected+" is detected from your account");
			response.setBalance(account.getCurrentBalance()- detected);
		}
		else
		{
			response.setMessage("No Detection");
			response.setBalance(account.getCurrentBalance());
		}
		return response;
	}


	
}
