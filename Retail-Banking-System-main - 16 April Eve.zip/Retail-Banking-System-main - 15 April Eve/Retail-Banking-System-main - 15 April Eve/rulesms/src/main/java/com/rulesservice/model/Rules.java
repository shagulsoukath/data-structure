package com.rulesservice.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name="rules")
public class Rules {
	
	@Id
	private String ruleKey;
	
	private String ruleDescription;
	
	private double rulededuction;
	
}
