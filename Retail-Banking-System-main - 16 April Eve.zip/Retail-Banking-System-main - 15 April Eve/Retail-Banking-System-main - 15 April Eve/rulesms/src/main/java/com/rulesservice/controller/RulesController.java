package com.rulesservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.rulesservice.exception.MinimumBalanceException;
import com.rulesservice.feign.AccountFeign;
import com.rulesservice.model.Account;
import com.rulesservice.model.AccountInput;
import com.rulesservice.model.RuleStatus;
import com.rulesservice.model.RulesInput;
import com.rulesservice.repository.RulesRepository;
import com.rulesservice.service.RulesService;

@RestController
public class RulesController {

	private static final String INVALID = "Send Valid Details.";
	@Autowired
	public RulesService rulesService;
	@Autowired
	@Qualifier("rulesRepository")
	RulesRepository rulesRepository;
	@Autowired
	AccountFeign accountFeign;

	// Check the minimum balance
	@PostMapping("/evaluateMinBal")
	public RuleStatus evaluate(@RequestBody RulesInput account) throws MinimumBalanceException {
		System.out.println("----------------Inside evaluate minimum bal-------------");
		if (account.getCurrentBalance() <1000) {
			throw new MinimumBalanceException(INVALID);
		} else {
			RuleStatus status = rulesService.evaluate(account);
			return status;
		}
	}

	// Service charges calculation
	@PostMapping("/serviceCharges")
	public ResponseEntity<?> serviceCharges(@RequestHeader("Authorization") String token) {
		// Jwt token is checked
		
		rulesService.hasPermission(token);
		
		double deductionAmount = rulesRepository.findById("minimumBalanceDeduction").get().getRulededuction();
		System.out.println(deductionAmount);
		double minimumBalanceForServiceCharge = rulesRepository.findById("minimumBalanceServiceCharge").get().getRulededuction();
		System.out.println(deductionAmount);
		try {
			List<Account> body = accountFeign.getAllacc(token).getBody();
			for (Account acc : body) {
				double detected = deductionAmount;
				System.out.println(acc.getCurrentBalance() < minimumBalanceForServiceCharge);
				if (acc.getCurrentBalance() < minimumBalanceForServiceCharge)
					accountFeign.servicecharge(token, new AccountInput(acc.getAccountId(), detected));
			}

		} catch (Exception e) {
			throw e;
		}
		return ResponseEntity.ok(accountFeign.getAllacc(token).getBody());
	}

	@PostMapping("/serviceChargesBatch")
	public ResponseEntity<?> serviceChargesBatch() {

		try {
			List<Account> body = accountFeign.getAllaccForBatch().getBody();
			double deductionAmount = rulesRepository.findById("minimumBalanceDeduction").get().getRulededuction();
			double minimumBalanceForServiceCharge = rulesRepository.findById("minimumBalanceServiceCharge").get().getRulededuction();
			for (Account acc : body) {
				double detected = deductionAmount;
				if (acc.getCurrentBalance() < minimumBalanceForServiceCharge && (acc.getCurrentBalance() - detected) > 0) {
					System.out.println("Inside");
					accountFeign.servicechargeForBatch(new AccountInput(acc.getAccountId(), detected));
				} 
			}

		} catch (Exception e) {
			throw e;
		}
		return ResponseEntity.ok(accountFeign.getAllaccForBatch().getBody());
	}
}
