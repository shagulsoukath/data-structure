package com.cognizant.transactionservice.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cognizant.transactionservice.models.Transaction;

public interface TransactionRepository extends JpaRepository<Transaction, Long> {

	//@Query("select t from Transaction where t.sourceAccountId =:id or t.targetAccountId = :id order by t.initiationDate")
    List<Transaction> findBySourceAccountIdOrTargetAccountIdOrderByInitiationDate(long id , long id2);

	List<Transaction> findByTargetAccountIdOrderByInitiationDate(long accId);

	List<Transaction> findBySourceAccountIdOrderByInitiationDate(int i);
	
	//SELECT * from Transaction where initiation_date between "2021-04-10" and "2021-04-13" and (source_account_id = 12345678 or target_account_id = 12345678) ; 
	
//	@Query(nativeQuery = true, value = "select t from Transaction t where (t.sourceAccountId =:accId or t.targetAccountId = :accId2) and t.initiationDate between :startDate and :endDate")
	@Query(nativeQuery = true, value = "select * from Transaction where (source_account_id =:accId or target_account_id = :accId2) and initiation_date between :startDate and :endDate")
	List<Transaction> findTransactionByDate(long accId, long accId2, String startDate, String endDate);
} 
