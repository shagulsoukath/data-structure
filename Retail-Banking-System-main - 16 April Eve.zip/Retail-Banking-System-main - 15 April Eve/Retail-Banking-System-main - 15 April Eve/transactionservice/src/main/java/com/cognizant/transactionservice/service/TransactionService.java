package com.cognizant.transactionservice.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.transactionservice.exception.MinimumBalanceException;
import com.cognizant.transactionservice.feign.AccountFeign;
import com.cognizant.transactionservice.feign.RulesFeign;
import com.cognizant.transactionservice.models.Account;
import com.cognizant.transactionservice.models.RulesInput;
import com.cognizant.transactionservice.models.Transaction;
import com.cognizant.transactionservice.models.TransactionStatus;
import com.cognizant.transactionservice.repository.TransactionRepository;
import com.cognizant.transactionservice.util.AccountInput;
import com.cognizant.transactionservice.util.TransactionInput;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class TransactionService {

	@Autowired
	private AccountFeign accountFeign;

	@Autowired
	private TransactionRepository transactionRepository;

	@Autowired
	private RulesFeign ruleFeign;

    
	private TransactionStatus transactionStatus;


	public TransactionStatus makeTransfer(String token, TransactionInput transactionInput) throws MinimumBalanceException {
		
		long sourceAccountNumber = transactionInput.getSourceAccount().getAccountId();
		Account sourceAccount = accountFeign.getAccount(token, sourceAccountNumber);
		System.out.println("---Control passing to evaluateMinBal-----");
			String check = ruleFeign.evaluate(new RulesInput(sourceAccount.getAccountId(),
					sourceAccount.getCurrentBalance(), transactionInput.getAmount())).getStatus();
			System.out.println("--------------------------------------------"+check+"------------------");
			if (check.equals("denied"))
				throw new MinimumBalanceException("Minimum Balance 1000 should be maintaind");
		
		long targetAccountNumber = transactionInput.getTargetAccount().getAccountId();
		Account targetAccount = accountFeign.getAccount(token, targetAccountNumber);
		transactionStatus = new TransactionStatus();
		System.out.println("Before make transfer if block");
		if (sourceAccount != null && targetAccount != null) {
			System.out.println(transactionInput.getAmount());
			System.out.println(sourceAccount.getCurrentBalance());
			if ((sourceAccount.getCurrentBalance() - transactionInput.getAmount())>0) {
				System.out.println("Inside make transfer if block");
				Transaction sourcetransaction = new Transaction();
				sourcetransaction.setAmount(transactionInput.getAmount());
				sourcetransaction.setSourceAccountId(sourceAccount.getAccountId());
				sourcetransaction.setSourceOwnerName(sourceAccount.getOwnerName());
				sourcetransaction.setTargetAccountId(targetAccount.getAccountId());
				sourcetransaction.setTargetOwnerName(targetAccount.getOwnerName());
				sourcetransaction.setInitiationDate(LocalDateTime.now());
				sourcetransaction.setReference("transfer");
				transactionRepository.save(sourcetransaction);
				transactionStatus.setStatus("Transaction Completed");
				System.out.println(transactionStatus.getStatus());
				return transactionStatus;
			}
		}
		transactionStatus.setStatus("Transaction Failed");
		System.out.println("make transfer failed");
		return transactionStatus;
	}
		
	public TransactionStatus makeWithdraw(String token, AccountInput accountInput) {
		log.info("method to make a withdraw");
		long accNumber = accountInput.getAccountId();
		Account sourceAccount = accountFeign.getAccount(token, accNumber);
		
			String check =  ruleFeign.evaluate(new RulesInput(accountInput.getAccountId(),
					sourceAccount.getCurrentBalance(), accountInput.getAmount() ) ).getStatus();
			transactionStatus = new TransactionStatus();
			if (check.equals("denied"))
				throw new MinimumBalanceException("Minimum Balance 1000 should be maintaind");
			if (sourceAccount != null) {
				Transaction transaction = new Transaction();
				transaction.setSourceAccountId(sourceAccount.getAccountId());
				transaction.setSourceOwnerName(sourceAccount.getOwnerName());
				transaction.setInitiationDate(LocalDateTime.now());
				transaction.setReference("withdrawl");
				transaction.setAmount(accountInput.getAmount());
				transactionRepository.save(transaction);
				transactionStatus.setStatus("Transaction Completed");
			}
			return transactionStatus;
	}
	

	public TransactionStatus makeServiceCharges(String token, AccountInput accountInput) {
		log.info("method to make a service charges");
		long accNumber = accountInput.getAccountId();
		Account sourceAccount = accountFeign.getAccount(token, accNumber);
		transactionStatus = new TransactionStatus();
		if (sourceAccount != null) {
			Transaction transaction = new Transaction();
			transaction.setSourceAccountId(sourceAccount.getAccountId());
			transaction.setSourceOwnerName(sourceAccount.getOwnerName());
			transaction.setInitiationDate(LocalDateTime.now());
			transaction.setReference("service charge");
			transaction.setAmount(accountInput.getAmount());
			transactionRepository.save(transaction);
			transactionStatus.setStatus("Transaction Completed");
			return transactionStatus;
		}
		transactionStatus.setStatus("Transaction Failed");
		return transactionStatus;
	}
	
	
	

	public TransactionStatus makeDeposit(String token, AccountInput accountInput) {
		log.info("method to make a deposit");
		long accNumber = accountInput.getAccountId();
		Account sourceAccount = accountFeign.getAccount(token, accNumber);
		transactionStatus = new TransactionStatus();
		if (sourceAccount != null) {
			Transaction transaction = new Transaction();
			transaction.setSourceAccountId(sourceAccount.getAccountId());
			transaction.setSourceOwnerName(sourceAccount.getOwnerName());
			transaction.setTargetAccountId(sourceAccount.getAccountId());
			transaction.setTargetOwnerName(sourceAccount.getOwnerName());
			transaction.setInitiationDate(LocalDateTime.now());
			transaction.setReference("deposit");
			transaction.setAmount(accountInput.getAmount());
			transactionRepository.save(transaction);
			transactionStatus.setStatus("Transaction Completed");
			System.out.println(transactionStatus);
			return transactionStatus;
		}
		transactionStatus.setStatus("Transaction Failed");
		return transactionStatus;
	}
	
	public TransactionStatus makeServiceChargesForBatch(AccountInput accountInput) {
		log.info("method to make a service charges for batch");
		Account sourceAccount = null;

		long accNumber = accountInput.getAccountId();
		sourceAccount = accountFeign.getAccountForBatch(accNumber);
		transactionStatus = new TransactionStatus();
		if (sourceAccount != null) {
			log.info("Inside Changing makeServiceChargesForBatch");
			Transaction transaction = new Transaction();
			transaction.setSourceAccountId(sourceAccount.getAccountId());
			transaction.setSourceOwnerName(sourceAccount.getOwnerName());
			transaction.setInitiationDate(LocalDateTime.now());
			transaction.setReference("service charge");
			transaction.setAmount(accountInput.getAmount());
			transactionRepository.save(transaction);
			transactionStatus.setStatus("Transaction Completed");
			System.out.println(transactionStatus);
			return transactionStatus;
		}
		
		transactionStatus.setStatus("Transaction Failed");
		return transactionStatus;
		
	}
}