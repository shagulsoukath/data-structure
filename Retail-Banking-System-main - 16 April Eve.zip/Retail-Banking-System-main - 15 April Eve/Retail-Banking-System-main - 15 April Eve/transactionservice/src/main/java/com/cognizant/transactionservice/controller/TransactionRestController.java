package com.cognizant.transactionservice.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.transactionservice.feign.AccountFeign;
import com.cognizant.transactionservice.feign.RulesFeign;
import com.cognizant.transactionservice.models.Transaction;
import com.cognizant.transactionservice.models.TransactionStatus;
import com.cognizant.transactionservice.repository.TransactionRepository;
import com.cognizant.transactionservice.service.TransactionService;
import com.cognizant.transactionservice.util.AccountInput;
import com.cognizant.transactionservice.util.TransactionInput;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class TransactionRestController {
	@Autowired
	AccountFeign accountFeign;

	@Autowired
	RulesFeign rulesFeign;

	@Autowired
	TransactionRepository transRepo;

	@Autowired
	TransactionService transactionService;
	
//	TransactionStatus transactionStatus;

	@PostMapping(value = "/transactions")
	public TransactionStatus makeTransfer(@RequestHeader("Authorization") String token,
			@Valid @RequestBody TransactionInput transactionInput) {
		log.info("inside transaction method");
		return transactionService.makeTransfer(token, transactionInput);

	}


	/*
	 * To get All transaction done in one account
	 */
	@GetMapping(value = "/getAllTransByAccId/{id}")
	public List<Transaction> getTransactionsByAccId(@RequestHeader("Authorization") String token,
			@PathVariable("id") long accId) {
		List<Transaction> slist = transRepo.findBySourceAccountIdOrTargetAccountIdOrderByInitiationDate(accId, accId);
		return slist;
	}
	
	@GetMapping(value = "/getTransactionsByAccIdWithStartAndEndDate/{id}/{startDate}/{endDate}")
	public List<Transaction> getTransactionsByAccIdWithStartAndEndDate(@RequestHeader("Authorization") String token,
			@PathVariable("id") long accId, @PathVariable("startDate") String startDate, @PathVariable("endDate") String endDate){
		List<Transaction> slist = transRepo.findTransactionByDate(accId, accId, startDate, endDate);
		System.out.println(slist);
		return slist;
	}

	/*
	 * Method for making a withdraw in one account
	 */
	@PostMapping(value = "/withdraw")
	public TransactionStatus makeWithdraw(@RequestHeader("Authorization") String token,
			@Valid @RequestBody AccountInput accountInput) {
		return transactionService.makeWithdraw(token, accountInput);
 	}

	@PostMapping(value = "/servicecharge")
	public TransactionStatus makeServiceCharges(@RequestHeader("Authorization") String token,
			@Valid @RequestBody AccountInput accountInput) {
		return transactionService.makeServiceCharges(token, accountInput);
	}

	/*
	 * Method for making a deposit in a account
	 */
	@PostMapping(value = "/deposit")
	public ResponseEntity<?> makeDeposit(@RequestHeader("Authorization") String token,
			@Valid @RequestBody AccountInput accountInput) {
		transactionService.makeDeposit(token, accountInput);
		return new ResponseEntity<>(true, HttpStatus.OK);
	}
	

	@GetMapping(value = "/getAllTransByAccIdForBatch/{id}")
	public List<Transaction> getTransactionsByAccIdForBatch(@PathVariable("id") long accId) {
		List<Transaction> slist = transRepo.findBySourceAccountIdOrTargetAccountIdOrderByInitiationDate(accId, accId);
		return slist;
	}
	
	@PostMapping(value = "/servicechargeforbatch")
	public TransactionStatus makeServiceCharges(@Valid @RequestBody AccountInput accountInput) {
		return transactionService.makeServiceChargesForBatch(accountInput);
	}
}